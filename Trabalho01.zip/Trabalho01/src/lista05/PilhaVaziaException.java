package lista05;

public class PilhaVaziaException extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
